import React from 'react';

export default function ProductCard({ product, addToCart }) {
  return (
    <div className="bg-white rounded-2xl shadow-md p-4 flex flex-col items-center">
      <img src={product.image} alt={product.name} className="h-32 object-contain mb-2" />
      <h2 className="text-pink-600 font-bold">{product.name}</h2>
      <p className="text-pink-500">{product.price}</p>
      <button
        onClick={() => addToCart(product)}
        className="mt-2 bg-pink-400 text-white px-4 py-1 rounded hover:bg-pink-500"
      >
        Añadir al carrito
      </button>
    </div>
  );
}