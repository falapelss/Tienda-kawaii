import React, { useState } from 'react';
import ProductCard from '../components/ProductCard';

const products = [
  { name: "Lip Gloss", price: "$8", image: "/images/lipgloss.png" },
  { name: "Sombras", price: "$12", image: "/images/sombras.png" },
  { name: "Delineador", price: "$9", image: "/images/delineador.png" },
  { name: "Iluminador", price: "$11", image: "/images/iluminador.png" },
  { name: "Rímel", price: "$10", image: "/images/rimel.png" },
  { name: "Brochas", price: "$15", image: "/images/brochas.png" },
  { name: "Lip Oil", price: "$7", image: "/images/lipoil.png" },
  { name: "Llavero de Maquillaje", price: "$6", image: "/images/llavero.png" },
];

export default function Home() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  return (
    <main className="min-h-screen bg-pink-50 p-4 font-sans">
      <h1 className="text-4xl font-bold text-center text-pink-600 mb-8">
        팔라펠스쨩 - Tienda Kawaii de Maquillaje
      </h1>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {products.map((product, index) => (
          <ProductCard key={index} product={product} addToCart={addToCart} />
        ))}
      </div>

      <div className="mt-10 text-center text-pink-500">
        <h2 className="text-xl font-semibold">Carrito ({cart.length})</h2>
        {cart.map((item, i) => (
          <p key={i}>{item.name} - {item.price}</p>
        ))}
      </div>
    </main>
  );
}